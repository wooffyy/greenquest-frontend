export default function Page() {
    return <div className="text-white p-6">[challange]</div>;
  }
  