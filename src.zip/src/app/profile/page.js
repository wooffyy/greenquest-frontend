"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

export default function ProfilePage() {
  const [form, setForm] = useState({
    fullName: "",
    nickName: "",
    gender: "",
    country: "",
    language: "",
    city: "",
    email: "",
    picture: null,
  });
  const [warnUnsaved, setWarnUnsaved] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (warnUnsaved) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [warnUnsaved]);

  const handleChange = (e) => {
    setWarnUnsaved(true);
    const { name, value, files } = e.target;
    setForm((o) => ({ ...o, [name]: files ? files[0] : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setWarnUnsaved(false);
    // call profile update API
    alert("Profile updated!");
  };

  const handleLogout = () => {
    // perform logout
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-black p-4 text-white">
      <h1 className="text-2xl mb-4 text-green-400">ecochallenge</h1>
      <form onSubmit={handleSubmit} className="bg-green-600 p-6 rounded-lg space-y-4">
        <div className="flex items-center mb-6">
          <div className="relative">
            <img src={form.picture ? URL.createObjectURL(form.picture) : "/images/default-avatar.png"} 
              alt="Profile" className="w-16 h-16 rounded-full cursor-pointer" />
            <input type="file" name="picture" accept="image/*"
              onChange={handleChange} className="absolute inset-0 opacity-0 cursor-pointer rounded-full" />
          </div>
          <div className="ml-4">
            <div className="text-lg font-semibold">{form.fullName || "Your Name"}</div>
            <div className="text-gray-200">{form.email || "No email added yet"}</div>
          </div>
          <button type="button" onClick={handleLogout}
            className="ml-auto bg-red-700 px-4 py-2 rounded">Log Out</button>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: "Full Name", name: "fullName" },
            { label: "Nick Name", name: "nickName" },
          ].map(f => (
            <input key={f.name} name={f.name} placeholder={f.label}
              value={form[f.name]} onChange={handleChange}
              className="col-span-1 border border-gray-300 rounded p-2 text-black" />
          ))}

          {[
            { label: "Gender", name: "gender", options: ["Male", "Female", "Rather not say"] },
            { label: "Country", name: "country", options: ["Indonesia", "USA", "UK", "Others"] },
            { label: "Language", name: "language", options: ["English", "Indonesian", "Spanish"] },
            { label: "City", name: "city", options: false },
          ].map(f => (
            f.options
            ? <select key={f.name} name={f.name} value={form[f.name]} onChange={handleChange}
                className="col-span-1 border border-gray-300 rounded p-2 text-black">
                <option value="">{f.label}</option>
                {f.options.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            : <input key={f.name} name={f.name} placeholder={f.label}
                value={form[f.name]} onChange={handleChange}
                className="col-span-1 border border-gray-300 rounded p-2 text-black" />
          ))}
        </div>

        <button type="submit" className="bg-blue-500 px-4 py-2 rounded">
          Update Profile
        </button>
      </form>
    </div>
  );
}
