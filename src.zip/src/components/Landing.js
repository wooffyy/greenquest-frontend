'use client';

import SocialAuth from '@/components/SocialAuth';
import { signIn } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';

const Heading = ({ children }) => (
  <h2 className="text-xl font-bold mb-6 text-center">{children}</h2>
);

export default function Landing({ mode }) {
  const router = useRouter();
  const params = useSearchParams();
  const [error, setError] = useState(params.get('error'));

  const handleLogin = async (e) => {
    e.preventDefault();
    const { email, password } = Object.fromEntries(new FormData(e.target));

    const res = await signIn('credentials', {
      email,
      password,
      redirect: true,
      callbackUrl: '/profile',
    });

    if (res?.error) setError(res.error);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));

    const save = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (save.ok) {
      router.push('/profile');
    } else {
      const { message } = await save.json();
      setError(message);
    }
  };

  const isLogin = mode === 'login';

  return (
    <main className="min-h-screen bg-black flex items-center justify-center p-4 relative">
      <a
        href="/"
        className="absolute left-6 top-6 text-2xl font-semibold text-green-400 drop-shadow"
      >
        ecochallenge
      </a>

      <div className="flex flex-col sm:flex-row items-center gap-6">
        {/* Social Card */}
        <div className="w-64 sm:w-72 p-8 rounded-2xl border-2 border-green-400 bg-gray-200 flex flex-col items-center">
          <Heading>{isLogin ? 'Log In' : 'Sign Up'}</Heading>
          <SocialAuth callbackUrl="/profile" />
        </div>

        {/* OR Separator */}
        <div className="flex flex-col items-center h-full relative">
          <div className="w-px h-24 sm:h-48 bg-[repeating-linear-gradient(to_bottom,_#555_0_6px,_transparent_6px_12px)]" />
          <span className="text-gray-300 font-semibold absolute top-1/2 transform -translate-y-1/2">
            OR
          </span>
        </div>

        {/* Email Card */}
        <div className="w-64 sm:w-72 p-8 rounded-2xl border-2 border-green-400 bg-green-50 flex flex-col items-center">
          <Heading>{isLogin ? 'Log In' : 'Sign Up'}</Heading>

          {error && (
            <p className="text-red-500 text-sm mb-4 text-center">{error}</p>
          )}

          <form
            onSubmit={isLogin ? handleLogin : handleRegister}
            className="w-full space-y-4"
          >
            {!isLogin && (
              <input
                type="text"
                name="name"
                placeholder="Name"
                className="w-full rounded-full border px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
                required
              />
            )}
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="w-full rounded-full border px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="w-full rounded-full border px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            />

            <button
              type="submit"
              className="w-full rounded-full bg-green-500 text-white py-2 text-sm font-semibold hover:brightness-110 active:brightness-95"
            >
              {isLogin ? 'Log In' : 'Sign Up'}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
