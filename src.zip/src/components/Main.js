export default function Main() {
    return (
        <div className="flex border-2 border-white">
           <section className="flex h-10">
                <div className="text-2xl font-semibold text-[#89F336]">ecoChallenge</div>
                <div className="text-2xl font-semibold absolute right-6 rounded-full bg-slate-400 px-2">A</div>
           </section>
           <section>
            
           </section>
        </div>
    );
}
