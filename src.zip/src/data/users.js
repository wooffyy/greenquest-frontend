const users = [
    {
      id: 1,
      fullName: "Captain Eco",
      username: "@capeco",
      points: 1259,
      avatar: "/avatars/avatar1.png",
    },
    {
      id: 2,
      fullName: "Eco Queen",
      username: "@ecoqueen",
      points: 1259,
      avatar: "/avatars/avatar2.png",
    },
    {
      id: 3,
      fullName: "Recyclo Man",
      username: "@recycloman",
      points: 1259,
      avatar: "/avatars/avatar3.png",
    },
    {
      id: 4,
      fullName: "Solar Sam",
      username: "@solarsam",
      points: 1259,
      avatar: "/avatars/avatar4.png",
    },
    {
      id: 5,
      fullName: "Green Grace",
      username: "@greengrace",
      points: 1259,
      avatar: "/avatars/avatar5.png",
    },
    {
      id: 6,
      fullName: "Bamboo Ben",
      username: "@bambooben",
      points: 1259,
      avatar: "/avatars/avatar6.png",
    },
    {
      id: 7,
      fullName: "Plastic Pete",
      username: "@plasticpete",
      points: 1259,
      avatar: "/avatars/avatar7.png",
    },
    {
      id: 8,
      fullName: "Climate Clara",
      username: "@climateclara",
      points: 1259,
      avatar: "/avatars/avatar8.png",
    },
    {
      id: 9,
      fullName: "Sustainable Steve",
      username: "@sustainablesteve",
      points: 1259,
      avatar: "/avatars/avatar9.png",
    },
    {
      id: 10,
      fullName: "Organic Olivia",
      username: "@organicolivia",
      points: 1259,
      avatar: "/avatars/avatar10.png",
    },
  ];
  
  export default users;
  