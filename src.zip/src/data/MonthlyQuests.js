const monthlyQuests = [
    "Post 5000 eco-activity",
    "Host a community clean-up",
    "Organize a recycling drive",
    "Lead a local sustainability workshop",
    "Audit your home energy use",
    "Switch to a green energy provider",
    "Volunteer for 20 eco-hours",
    "Eliminate single-use plastics for 30 days",
    "Document 30 sustainable meals",
    "Mentor 5 eco-newbies",
    // ...extend to 100 total entries
  ];
  
  export default monthlyQuests;
  