const dailyQuests = [
    "Post 10 eco-activity",
    "Review 10 posts",
    "Join 1 community event",
    "Recycle 5 plastic items",
    "Plant a tree",
    "Walk or bike to work",
    "Use reusable shopping bags",
    "Compost your food waste",
    "Turn off unused electronics",
    "Take a shorter shower",
    // ...repeat up to 1000 total
  ];
  
  export default dailyQuests;
  